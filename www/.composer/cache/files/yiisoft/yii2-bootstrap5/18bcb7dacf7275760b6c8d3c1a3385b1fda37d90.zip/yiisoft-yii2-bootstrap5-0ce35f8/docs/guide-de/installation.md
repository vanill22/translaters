Installation
============

## Mittels Composer Package

Der empfohlene Weg zur Installation dieser Erweiterung ist mittels [composer](http://getcomposer.org/download/).

Führen Sie entweder folgenden Befehlt aus

```
php composer.phar require --prefer-dist yiisoft/yii2-bootstrap5
```

oder fügen Sie folgendes

```
"yiisoft/yii2-bootstrap5": "~1.0.0"
```

zur `require`-Sektion Ihrer `composer.json`-Datei hinzu.
