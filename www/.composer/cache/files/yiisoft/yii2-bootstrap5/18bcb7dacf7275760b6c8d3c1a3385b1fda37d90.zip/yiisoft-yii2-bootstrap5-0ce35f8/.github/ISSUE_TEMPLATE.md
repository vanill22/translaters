<!--
Please use this issue tracker for bugs and feature requests only. In case you need support please use one of
Yii communities listed at https://github.com/yiisoft/yii2/wiki/communities
-->

### What steps will reproduce the problem?

### What is the expected result?

### What do you get instead?


### Additional info

| Q                | A
| ---------------- | ---
| Yii vesion       |
| PHP version      |
| Operating system |
