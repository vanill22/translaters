Instalação
============

## Instalando através do composer

A maneira recomendada para instalar esta extensão é através do [composer](http://getcomposer.org/download/).

Então rode

```
php composer.phar require --prefer-dist yiisoft/yii2-bootstrap5
```

Ou Adicione

```
"yiisoft/yii2-bootstrap": "~1.0.0"
```

na sessão de requirimentos do seu arquivo `composer.json`.
