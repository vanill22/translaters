<?php

declare(strict_types=1);

namespace Codeception\Exception;

use RuntimeException;

class TestRuntimeException extends RuntimeException
{
}
